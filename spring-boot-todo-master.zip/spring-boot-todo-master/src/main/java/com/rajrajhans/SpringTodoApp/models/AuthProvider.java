package com.rajrajhans.SpringTodoApp.models;

public enum AuthProvider {
    local,
    facebook,
    google,
    github
}
