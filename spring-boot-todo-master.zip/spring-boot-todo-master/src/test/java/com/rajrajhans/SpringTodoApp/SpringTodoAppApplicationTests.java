package com.rajrajhans.SpringTodoApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTodoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
